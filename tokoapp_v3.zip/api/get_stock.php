<?php
require_once __DIR__.'/../config.php';
$kode = $_GET['kode'] ?? '';
$loc = $_GET['loc'] ?? 'toko';
$stmt = $pdo->prepare("SELECT qty FROM item_stocks WHERE item_kode=? AND location=?");
$stmt->execute([$kode, $loc]);
$row = $stmt->fetch();
header('Content-Type: application/json');
echo json_encode(['qty' => $row ? (int)$row['qty'] : 0]);
