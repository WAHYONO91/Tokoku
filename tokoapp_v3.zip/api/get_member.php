<?php
require_once __DIR__.'/../config.php';
$q = trim($_GET['q'] ?? '');
if($q===''){ echo json_encode(null); exit; }
$stmt = $pdo->prepare("SELECT * FROM members WHERE kode=? LIMIT 1");
$stmt->execute([$q]);
$member = $stmt->fetch();
header('Content-Type: application/json');
echo json_encode($member);
