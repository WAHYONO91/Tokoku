<?php
require_once __DIR__.'/../config.php';
$q = trim($_GET['q'] ?? '');
if($q===''){ echo json_encode(null); exit; }
$stmt = $pdo->prepare("SELECT * FROM items WHERE kode=? OR barcode=? LIMIT 1");
$stmt->execute([$q,$q]);
$item = $stmt->fetch();
header('Content-Type: application/json');
echo json_encode($item);
