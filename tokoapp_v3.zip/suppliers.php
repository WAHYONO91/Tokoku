<?php
require_once __DIR__.'/includes/header.php';
require_login();
if($_SESSION['user']['role']!=='admin'){ echo "<p>Akses khusus admin.</p>"; include __DIR__.'/includes/footer.php'; exit; }

if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['save'])){
    $nama = $_POST['nama']; $alamat = $_POST['alamat']; $tlp = $_POST['tlp'];
    $stmt = $pdo->prepare("INSERT INTO suppliers(nama, alamat, tlp) VALUES(?,?,?)");
    $stmt->execute([$nama,$alamat,$tlp]);
  }
  if(isset($_POST['delete'])){
    $id = (int)$_POST['id'];
    $pdo->prepare("DELETE FROM suppliers WHERE id=?")->execute([$id]);
  }
}
$sup = $pdo->query("SELECT * FROM suppliers ORDER BY id DESC LIMIT 200")->fetchAll();
?>
<article>
  <h3>Master Supplier</h3>
  <details open><summary>Tambah Supplier</summary>
    <form method="post" class="grid">
      <label>Nama <input name="nama" required></label>
      <label>Alamat <input name="alamat"></label>
      <label>Telepon <input name="tlp"></label>
      <button name="save" value="1">Simpan</button>
    </form>
  </details>
  <h4>Daftar Supplier</h4>
  <table class="table-small">
    <thead><tr><th>ID</th><th>Nama</th><th>Alamat</th><th>Telepon</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php foreach($sup as $s): ?>
      <tr>
        <td><?=$s['id']?></td>
        <td><?=htmlspecialchars($s['nama'])?></td>
        <td><?=htmlspecialchars($s['alamat'])?></td>
        <td><?=htmlspecialchars($s['tlp'])?></td>
        <td>
          <form method="post" class="no-print" onsubmit="return confirm('Hapus supplier?')">
            <input type="hidden" name="id" value="<?=$s['id']?>">
            <button name="delete" value="1" class="contrast outline">Hapus</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</article>
<?php include __DIR__.'/includes/footer.php'; ?>
