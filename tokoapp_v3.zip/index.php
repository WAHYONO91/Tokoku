<?php
require_once __DIR__.'/includes/header.php';
require_login();
?>
<article>
  <h3>Dashboard</h3>
  <p>Halo, <strong><?php echo htmlspecialchars($_SESSION['user']['username']); ?></strong> (<?php echo $_SESSION['user']['role']; ?>)</p>
  <p>Gunakan menu di atas untuk mengelola data dan melakukan penjualan.</p>

  <?php
    // /*lowstock*/ tampilkan 10 barang stok rendah (toko/gudang)
    $low = $pdo->query("SELECT i.kode, i.nama,
      COALESCE((SELECT qty FROM item_stocks WHERE item_kode=i.kode AND location='gudang'),0) sg,
      COALESCE((SELECT qty FROM item_stocks WHERE item_kode=i.kode AND location='toko'),0) st,
      i.min_stock
      FROM items i
      WHERE i.min_stock>0 AND (
        COALESCE((SELECT qty FROM item_stocks WHERE item_kode=i.kode AND location='gudang'),0) < i.min_stock
        OR COALESCE((SELECT qty FROM item_stocks WHERE item_kode=i.kode AND location='toko'),0) < i.min_stock
      )
      ORDER BY i.nama LIMIT 10")->fetchAll();
    if($low){
      echo "<h4>⚠️ Stok Rendah</h4>";
      echo '<table class="table-small"><thead><tr><th>Kode</th><th>Nama</th><th>Min</th><th>Gudang</th><th>Toko</th></tr></thead><tbody>';
      foreach($low as $r){
        echo "<tr><td>".htmlspecialchars($r['kode'])."</td><td>".htmlspecialchars($r['nama'])."</td><td>{$r['min_stock']}</td><td class='right'>{$r['sg']}</td><td class='right'>{$r['st']}</td></tr>";
      }
      echo "</tbody></table>";
    }
  ?>
</article>
<?php include __DIR__.'/includes/footer.php'; ?>
