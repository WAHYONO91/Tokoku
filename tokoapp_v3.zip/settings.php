<?php
require_once __DIR__.'/includes/header.php';
require_login();
require_role(['admin']);
if($_SERVER['REQUEST_METHOD']==='POST'){
  $rate = (float)($_POST['points_per_rupiah'] ?? 0.0001);
  $pdo->prepare("UPDATE settings SET points_per_rupiah=? WHERE id=1")->execute([$rate]);
}
$set = get_setting($pdo,1);
?>
<article>
  <h3>Pengaturan</h3>
  <form method="post" class="grid">
    <label>Poin per Rupiah (contoh: 0.0001 = 1 poin per Rp10.000)
      <input type="number" step="0.000001" name="points_per_rupiah" value="<?=$set['points_per_rupiah']?>">
    </label>
    <button>Simpan</button>
  </form>
</article>
<?php include __DIR__.'/includes/footer.php'; ?>
