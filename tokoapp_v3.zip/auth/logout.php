<?php
require_once __DIR__.'/../config.php';
session_destroy();
header('Location: /tokoapp/auth/login.php');
exit;
