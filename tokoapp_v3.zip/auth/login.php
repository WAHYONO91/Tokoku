<?php
require_once __DIR__.'/../config.php';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  $username = $_POST['username'] ?? '';
  $password = $_POST['password'] ?? '';
  $stmt = $pdo->prepare("SELECT * FROM users WHERE username=?");
  $stmt->execute([$username]);
  $user = $stmt->fetch();
  if ($user && password_verify($password, $user['password_hash'])) {
    $_SESSION['user'] = ['id'=>$user['id'], 'username'=>$user['username'], 'role'=>$user['role']];
    header('Location: /tokoapp/index.php');
    exit;
  } else {
    $error = "Username atau password salah";
  }
}
?>
<?php include __DIR__.'/../includes/header.php'; ?>
<article>
  <h3>Login</h3>
  <?php if(isset($error)): ?><mark><?php echo $error; ?></mark><?php endif; ?>
  <form method="post">
    <label>Username
      <input type="text" name="username" required>
    </label>
    <label>Password
      <input type="password" name="password" required>
    </label>
    <button type="submit">Masuk</button>
  </form>
  <p class="no-print"><small>Default admin: <code>admin / admin123</code> (ubah setelah login)</small></p>
</article>
<?php include __DIR__.'/../includes/footer.php'; ?>
