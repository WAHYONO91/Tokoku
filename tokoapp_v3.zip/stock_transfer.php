<?php
require_once __DIR__.'/includes/header.php';
require_login();
require_role(['admin']);

if($_SERVER['REQUEST_METHOD']==='POST'){
  $payload = json_decode($_POST['payload'] ?? 'null', true);
  if($payload){
    $from = $payload['from']; $to = $payload['to']; $note = $payload['note'] ?? null;
    $items = $payload['items'] ?? [];
    if($from===$to){ echo "<mark>Lokasi asal dan tujuan tidak boleh sama.</mark>"; }
    else {
      $pdo->beginTransaction();
      try{
        $stmt=$pdo->prepare("INSERT INTO stock_transfers(user_id,from_location,to_location,note) VALUES(?,?,?,?)");
        $stmt->execute([$_SESSION['user']['id'],$from,$to,$note]);
        $tid = $pdo->lastInsertId();
        $stmtDet=$pdo->prepare("INSERT INTO stock_transfer_items(transfer_id,item_kode,qty) VALUES(?,?,?)");
        foreach($items as $it){
          $stmtDet->execute([$tid, $it['kode'], (int)$it['qty']]);
          adjust_stock($pdo, $it['kode'], $from, -((int)$it['qty']));
          adjust_stock($pdo, $it['kode'], $to, (int)$it['qty']);
        }
        $pdo->commit();
        echo "<mark>Mutasi #$tid berhasil.</mark>";
      } catch(Exception $e){
        $pdo->rollBack();
        echo "<mark>Gagal mutasi: ".$e->getMessage()."</mark>";
      }
    }
  }
}
?>
<article>
  <h3>Mutasi Stok (Gudang ↔ Toko)</h3>
  <div class="grid">
    <label>Dari
      <select id="from">
        <option value="gudang">Gudang</option>
        <option value="toko">Toko</option>
      </select>
    </label>
    <label>Ke
      <select id="to">
        <option value="toko">Toko</option>
        <option value="gudang">Gudang</option>
      </select>
    </label>
    <label>Catatan
      <input id="note" placeholder="opsional">
    </label>
  </div>

  <article>
    <header>Tambah barang (barcode/kode lalu Enter)</header>
    <input id="barcode" placeholder="Barcode / Kode Barang" autofocus>
  </article>

  <table class="table-small" id="tbl">
    <thead><tr><th>Kode</th><th>Nama</th><th class="right">Qty</th><th class="right">Stok Asal</th><th></th></tr></thead>
    <tbody></tbody>
  </table>

  <form method="post" onsubmit="return doSave(event)">
    <input type="hidden" name="payload" id="payload">
    <button class="no-print">Simpan Mutasi</button>
  </form>
</article>

<script>
const rows=[];
const tbody=document.querySelector('#tbl tbody');
const barcodeEl=document.getElementById('barcode');

function fmt(n){ return new Intl.NumberFormat('id-ID').format(n); }

async function fetchItem(q){
  const res=await fetch('/tokoapp/api/get_item.php?q='+encodeURIComponent(q));
  return await res.json();
}
async function fetchStock(kode,loc){
  const res=await fetch('/tokoapp/api/get_stock.php?kode='+encodeURIComponent(kode)+'&loc='+encodeURIComponent(loc));
  const j=await res.json(); return j?.qty ?? 0;
}

barcodeEl.addEventListener('keypress', async (e)=>{
  if(e.key==='Enter'){
    e.preventDefault();
    const q=barcodeEl.value.trim(); if(!q) return;
    const it=await fetchItem(q);
    if(!it || !it.kode){ alert('Barang tidak ditemukan'); barcodeEl.value=''; return; }
    const from=document.getElementById('from').value;
    const stok = await fetchStock(it.kode, from);
    const exist = rows.find(r=>r.kode===it.kode);
    if(exist){ exist.qty++; } else { rows.push({kode:it.kode, nama:it.nama, qty:1, stok_asal:stok}); }
    barcodeEl.value=''; render();
  }
});

function render(){
  tbody.innerHTML='';
  rows.forEach((r,idx)=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`<td>${r.kode}</td><td>${r.nama}</td>
      <td class="right"><input type="number" min="1" value="${r.qty}" data-idx="${idx}" style="width:5rem"></td>
      <td class="right">${fmt(r.stok_asal)}</td>
      <td><button data-idx="${idx}" class="outline contrast">Hapus</button></td>`;
    tbody.appendChild(tr);
  });
  bind();
}
function bind(){
  tbody.querySelectorAll('input').forEach(inp=>{
    inp.onchange=(e)=>{ rows[parseInt(e.target.dataset.idx)].qty=parseInt(e.target.value||'1'); };
  });
  tbody.querySelectorAll('button').forEach(btn=>{
    btn.onclick=(e)=>{ e.preventDefault(); rows.splice(parseInt(btn.dataset.idx),1); render(); };
  });
}
function doSave(e){
  e.preventDefault();
  if(rows.length===0){ alert('Belum ada item'); return false; }
  const payload={
    from: document.getElementById('from').value,
    to: document.getElementById('to').value,
    note: document.getElementById('note').value,
    items: rows.map(r=>({kode:r.kode, qty:r.qty}))
  };
  document.getElementById('payload').value = JSON.stringify(payload);
  e.target.submit();
  return true;
}
</script>
<?php include __DIR__.'/includes/footer.php'; ?>
