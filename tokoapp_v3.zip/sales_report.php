<?php
require_once __DIR__.'/includes/header.php';
require_login();
// Kasir boleh akses laporan penjualan
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$shift = $_GET['shift'] ?? '';
$user = $_GET['user'] ?? '';

$sql = "SELECT s.*, u.username, m.nama as member_nama FROM sales s
        JOIN users u ON u.id=s.user_id
        LEFT JOIN members m ON m.kode=s.member_kode
        WHERE DATE(s.tanggal) BETWEEN ? AND ?";
$params = [$from, $to];
if($shift==='1' || $shift==='2'){ $sql.=" AND s.shift=?"; $params[]=$shift; }
if($user!==''){ $sql.=" AND u.username=?"; $params[]=$user; }
$sql.=" ORDER BY s.tanggal DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$data = $stmt->fetchAll();
$grand = 0; foreach($data as $d){ $grand += $d['total']; }
$users = $pdo->query("SELECT username FROM users ORDER BY username")->fetchAll();
?>
<article>
  <h3>Laporan Penjualan</h3>
  <form method="get" class="grid no-print">
    <label>Dari <input type="date" name="from" value="<?=$from?>"></label>
    <label>Sampai <input type="date" name="to" value="<?=$to?>"></label>
    <label>Shift
      <select name="shift">
        <option value="">Semua</option>
        <option value="1" <?=$shift==='1'?'selected':''?>>1</option>
        <option value="2" <?=$shift==='2'?'selected':''?>>2</option>
      </select>
    </label>
    <label>Kasir
      <select name="user">
        <option value="">Semua</option>
        <?php foreach($users as $u): ?>
          <option value="<?=$u['username']?>" <?=$user===$u['username']?'selected':''?>><?=$u['username']?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <button>Filter</button>
    <button type="button" onclick="window.print()">Cetak</button>
  </form>

  <table class="table-small">
    <thead><tr><th>Tanggal</th><th>Kasir</th><th>Shift</th><th>Member</th><th class="right">Total</th><th>Faktur</th></tr></thead>
    <tbody>
      <?php foreach($data as $d): ?>
      <tr>
        <td><?=$d['tanggal']?></td>
        <td><?=$d['username']?></td>
        <td><?=$d['shift']?></td>
        <td><?=htmlspecialchars($d['member_nama'] ?? '-')?></td>
        <td class="right"><?=rupiah($d['total'])?></td>
        <td><a href="/tokoapp/invoice.php?id=<?=$d['id']?>" target="_blank">Lihat</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot><tr><th colspan="4" class="right">Grand Total</th><th class="right"><?=rupiah($grand)?></th><th></th></tr></tfoot>
  </table>
</article>
<?php include __DIR__.'/includes/footer.php'; ?>
