<?php
require_once __DIR__.'/includes/header.php';
require_login();
// Kasir & Admin boleh mengakses POS
?>
<article>
  <h3>Penjualan (POS)</h3>
  <form id="posForm" method="post" action="save_sale.php" onsubmit="return handleSubmit(event)">
    <div class="grid">
      <label>Member (opsional)
        <input list="memberlist" name="member_kode" id="member_kode" placeholder="Ketik kode member">
        <datalist id="memberlist">
          <?php
          $mm = $pdo->query("SELECT kode, nama FROM members ORDER BY created_at DESC LIMIT 200")->fetchAll();
          foreach($mm as $m){ echo '<option value="'.htmlspecialchars($m['kode']).'">'.htmlspecialchars($m['nama']).'</option>'; }
          ?>
        </datalist>
      </label>
      <label>Shift
        <select name="shift">
          <option value="1">1</option>
          <option value="2">2</option>
        </select>
      </label>
      <label>Level Harga
        <select id="levelHarga" name="level_harga_default">
          <option value="1">Harga 1</option>
          <option value="2">Harga 2</option>
          <option value="3">Harga 3</option>
          <option value="4">Harga 4</option>
        </select>
      </label>
    </div>

    <article>
      <header>Scan/ketik barcode lalu Enter</header>
      <input class="pos-input" id="barcode" placeholder="Barcode / Kode Barang" autofocus>
    </article>

    <table class="table-small" id="cartTable">
      <thead>
        <tr><th>Kode</th><th>Nama</th><th class="right">Qty</th><th class="right">Harga</th><th class="right">Total</th><th class="no-print">Aksi</th></tr>
      </thead>
      <tbody></tbody>
      <tfoot>
        <tr><th colspan="4" class="right">Subtotal</th><th class="right" id="subtotal">0</th><th></th></tr>
        <tr><th colspan="4" class="right">Diskon</th><th class="right" id="tdiscount">0</th><th></th></tr>
        <tr><th colspan="4" class="right">PPN/Pajak</th><th class="right" id="ttax">0</th><th></th></tr>
        <tr><th colspan="4" class="right">Total</th><th class="right" id="gtotal">0</th><th></th></tr>
      </tfoot>
    </table>

    <div class="grid">
      <label>Diskon (Rp)
        <input type="number" name="discount" id="discount" min="0" value="0">
      </label>
      <label>PPN/Pajak (Rp)
        <input type="number" name="tax" id="tax" min="0" value="0">
      </label>
      <label>Tunai
        <input type="number" name="tunai" id="tunai" min="0" value="0">
      </label>
      <label>Kembalian
        <input type="number" id="kembalian" value="0" readonly>
      </label>
    </div>

    <input type="hidden" name="payload" id="payload">
    <button type="submit" class="no-print">Simpan & Cetak</button>
  </form>
</article>

<script>
const cart = [];
const tbody = document.querySelector('#cartTable tbody');
const subtotalEl = document.getElementById('subtotal');
const discountEl=document.getElementById('discount');
const taxEl=document.getElementById('tax');
const tdiscountEl=document.getElementById('tdiscount');
const ttaxEl=document.getElementById('ttax');
const gtotalEl=document.getElementById('gtotal');
const barcodeEl = document.getElementById('barcode');
const tunaiEl = document.getElementById('tunai');
const kembalianEl = document.getElementById('kembalian');
const levelHargaSel = document.getElementById('levelHarga');

function formatRupiah(n){ return new Intl.NumberFormat('id-ID').format(n); }

barcodeEl.addEventListener('keypress', async (e)=>{
  if(e.key === 'Enter'){
    e.preventDefault();
    const code = barcodeEl.value.trim();
    if(!code) return;
    const res = await fetch('/tokoapp/api/get_item.php?q='+encodeURIComponent(code));
    const item = await res.json();
    if(item && item.kode){
      addToCart(item);
    } else {
      alert('Barang tidak ditemukan');
    }
    barcodeEl.value='';
  }
});

function addToCart(item){
  const level = parseInt(levelHargaSel.value||'1');
  const harga = parseInt(item['harga_jual'+level]) || 0;
  const exist = cart.find(r=>r.kode===item.kode && r.level===level);
  if(exist){ exist.qty+=1; } else {
    cart.push({kode:item.kode, nama:item.nama, qty:1, level, harga});
  }
  renderCart();
}

function renderCart(){
  tbody.innerHTML='';
  let subtotal=0;
  cart.forEach((r,idx)=>{
    const total = r.qty * r.harga;
    subtotal += total;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${r.kode}<input type="hidden" value="${r.kode}"></td>
      <td>${r.nama}</td>
      <td class="right"><input type="number" min="1" value="${r.qty}" style="width:5rem" data-idx="${idx}" class="qtyInput"></td>
      <td class="right">${formatRupiah(r.harga)}</td>
      <td class="right">${formatRupiah(total)}</td>
      <td class="no-print"><button data-idx="${idx}" class="outline contrast delBtn">Hapus</button></td>
    `;
    tbody.appendChild(tr);
  });
  subtotalEl.textContent = formatRupiah(subtotal);
  const disc=parseInt(discountEl.value||'0'); const tax=parseInt(taxEl.value||'0');
  tdiscountEl.textContent=formatRupiah(disc);
  ttaxEl.textContent=formatRupiah(tax);
  const grand = subtotal - disc + tax; gtotalEl.textContent=formatRupiah(grand);
  hitungKembalian();
  bindRowEvents();
}

function bindRowEvents(){
  document.querySelectorAll('.qtyInput').forEach(inp=>{
    inp.onchange = (e)=>{
      const idx = parseInt(e.target.dataset.idx);
      const v = parseInt(e.target.value||'1');
      cart[idx].qty = v>0? v:1;
      renderCart();
    }
  });
  document.querySelectorAll('.delBtn').forEach(btn=>{
    btn.onclick = (e)=>{
      const idx = parseInt(e.target.dataset.idx);
      cart.splice(idx,1);
      renderCart();
    }
  });
}

function hitungKembalian(){
  let subtotal = cart.reduce((a,b)=>a+b.qty*b.harga,0);
  let disc=parseInt(discountEl.value||'0'); let tax=parseInt(taxEl.value||'0');
  let total = subtotal - disc + tax;
  let tunai = parseInt(tunaiEl.value||'0');
  let kembalian = tunai - total;
  kembalianEl.value = kembalian>=0? kembalian: 0;
}

tunaiEl.addEventListener('input', hitungKembalian);
discountEl.addEventListener('input', ()=>{renderCart();});
taxEl.addEventListener('input', ()=>{renderCart();});

function handleSubmit(e){
  e.preventDefault();
  if(cart.length===0){ alert('Keranjang kosong'); return false; }
  const payload = {
    member_kode: document.getElementById('member_kode').value || null,
    shift: document.querySelector('select[name=shift]').value,
    tunai: parseInt(tunaiEl.value||'0'),
    items: cart,
    discount: parseInt(discountEl.value||'0'),
    tax: parseInt(taxEl.value||'0')
  };
  document.getElementById('payload').value = JSON.stringify(payload);
  e.target.submit();
  return true;
}
</script>
<?php include __DIR__.'/includes/footer.php'; ?>
