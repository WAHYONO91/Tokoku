<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/includes/functions.php';
require_login();

$payload = json_decode($_POST['payload'] ?? 'null', true);
if(!$payload){ die('Payload kosong'); }
$member_kode = $payload['member_kode'] ?? null;
$shift = $payload['shift'] ?? '1';
$tunai = (int)($payload['tunai'] ?? 0);
$discount = (int)($payload['discount'] ?? 0);
$tax = (int)($payload['tax'] ?? 0);
$items = $payload['items'] ?? [];

$pdo->beginTransaction();
try {
  // Hitung total
  $subtotal = 0;
  foreach($items as $it){ $subtotal += ((int)$it['qty']) * ((int)$it['harga']); }
  $total = max(0, $subtotal - $discount + $tax);
  $kembalian = max(0, $tunai - $total);

  // Poin
  $set = get_setting($pdo,1);
  $poin = (int) floor($total * (float)$set['points_per_rupiah']);

  // Insert sales
  $stmt = $pdo->prepare("INSERT INTO sales(user_id, member_kode, subtotal, discount, tax, total, tunai, kembalian, poin_didapat, shift) VALUES(?,?,?,?,?,?,?,?,?,?)");
  $stmt->execute([$_SESSION['user']['id'], $member_kode, $subtotal, $discount, $tax, $total, $tunai, $kembalian, $poin, $shift]);
  $sale_id = $pdo->lastInsertId();

  // Insert items
  $stmtDet = $pdo->prepare("INSERT INTO sale_items(sale_id, item_kode, nama_item, qty, level_harga, harga_satuan, total) VALUES(?,?,?,?,?,?,?)");
  foreach($items as $it){
    $stmtDet->execute([$sale_id, $it['kode'], $it['nama'], (int)$it['qty'], (int)$it['level'], (int)$it['harga'], (int)$it['qty']*(int)$it['harga']]);
    adjust_stock($pdo, $it['kode'], 'toko', -((int)$it['qty']));
  }

  // Update poin member
  if($member_kode){
    $pdo->prepare("UPDATE members SET poin = poin + ? WHERE kode=?")->execute([$poin, $member_kode]);
  }

  $pdo->commit();
  header('Location: /tokoapp/invoice.php?id='.$sale_id);
  exit;
} catch(Exception $e){
  $pdo->rollBack();
  die('Gagal simpan: '.$e->getMessage());
}
