</main>
<footer class="container no-print">
  <small>© <?php echo date('Y'); ?> TokoApp • Simple POS untuk XAMPP</small>
</footer>
</body>
</html>
