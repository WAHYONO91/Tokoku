<?php require_once __DIR__.'/../config.php'; require_once __DIR__.'/functions.php'; ?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>TokoApp</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
  <style>
    .right { text-align:right; }
    .hide { display:none; }
    .table-small td, .table-small th { padding: .4rem .5rem; }
    .pos-input { font-size: 1.2rem; }
    @media print { nav, .no-print { display: none !important; } }
  </style>
</head>
<body>
<nav class="container-fluid">
  <ul>
    <li><strong>TokoApp</strong></li>
  </ul>
  <ul>
    <?php if(is_logged_in()): ?>
      <li><a href="/tokoapp/index.php">Dashboard</a></li>
      <?php if($_SESSION['user']['role']==='admin'): ?>
      <li><a href="/tokoapp/items.php">Master Barang</a></li>
      <li><a href="/tokoapp/suppliers.php">Master Supplier</a></li>
      <li><a href="/tokoapp/purchases.php">Pembelian</a></li>
      <li><a href="/tokoapp/stock_transfer.php">Mutasi</a></li>
      <li><a href="/tokoapp/stock_report.php">Laporan Stok</a></li>
      <li><a href="/tokoapp/returns.php">Retur</a></li>
      <li><a href="/tokoapp/import_csv.php">Import CSV</a></li>
      <li><a href="/tokoapp/members.php">Member</a></li>
      <li><a href="/tokoapp/settings.php">Pengaturan</a></li>
      <?php endif; ?>
      <li><a href="/tokoapp/pos.php">Penjualan</a></li>
      <li><a href="/tokoapp/sales_report.php">Laporan</a></li>
      <li><a href="/tokoapp/auth/logout.php">Logout</a></li>
    <?php else: ?>
      <li><a href="/tokoapp/auth/login.php">Login</a></li>
    <?php endif; ?>
  </ul>
</nav>
<main class="container">
