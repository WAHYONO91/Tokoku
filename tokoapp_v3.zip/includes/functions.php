<?php
function is_logged_in() {
  return isset($_SESSION['user']);
}

function require_login() {
  if (!is_logged_in()) {
    header('Location: /tokoapp/auth/login.php');
    exit;
  }
}

function require_role($roles = []) {
  if (!is_logged_in()) { header('Location: /tokoapp/auth/login.php'); exit; }
  if (!in_array($_SESSION['user']['role'], $roles)) {
    http_response_code(403);
    echo "<h3>Akses ditolak</h3>";
    exit;
  }
}

function rupiah($number) {
  return 'Rp ' . number_format($number, 0, ',', '.');
}

function get_setting($pdo, $id = 1) {
  $stmt = $pdo->prepare("SELECT * FROM settings WHERE id=?");
  $stmt->execute([$id]);
  return $stmt->fetch();
}
?>

function ensure_stock_rows($pdo, $item_kode){
  $stmt = $pdo->prepare("INSERT INTO item_stocks(item_kode,location,qty) VALUES(?, 'gudang', 0) ON DUPLICATE KEY UPDATE qty=qty");
  $stmt->execute([$item_kode]);
  $stmt = $pdo->prepare("INSERT INTO item_stocks(item_kode,location,qty) VALUES(?, 'toko', 0) ON DUPLICATE KEY UPDATE qty=qty");
  $stmt->execute([$item_kode]);
}
function get_stock($pdo, $item_kode, $location){
  $stmt = $pdo->prepare("SELECT qty FROM item_stocks WHERE item_kode=? AND location=?");
  $stmt->execute([$item_kode, $location]);
  $row = $stmt->fetch();
  return $row ? (int)$row['qty'] : 0;
}
function adjust_stock($pdo, $item_kode, $location, $delta_qty){
  ensure_stock_rows($pdo, $item_kode);
  $stmt = $pdo->prepare("UPDATE item_stocks SET qty = qty + ? WHERE item_kode=? AND location=?");
  $stmt->execute([(int)$delta_qty, $item_kode, $location]);
}
