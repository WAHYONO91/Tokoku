<?php
require_once __DIR__.'/includes/header.php';
require_login();
require_role(['admin']);

// Handle save
if($_SERVER['REQUEST_METHOD']==='POST'){
  $payload = json_decode($_POST['payload'] ?? 'null', true);
  if($payload){
    $location = $payload['location'] ?? 'gudang';
    $supplier_id = $payload['supplier_id'] ? (int)$payload['supplier_id'] : null;
    $items = $payload['items'] ?? [];
    $subtotal = 0;
    foreach($items as $it){ $subtotal += ((int)$it['qty']) * ((int)$it['harga_beli']); }
    $total = $subtotal;
    $pdo->beginTransaction();
    try{
      $stmt = $pdo->prepare("INSERT INTO purchases(user_id,supplier_id,location,subtotal,total) VALUES(?,?,?,?,?)");
      $stmt->execute([$_SESSION['user']['id'],$supplier_id,$location,$subtotal,$total]);
      $pid = $pdo->lastInsertId();
      $stmtDet = $pdo->prepare("INSERT INTO purchase_items(purchase_id,item_kode,nama_item,qty,harga_beli,total) VALUES(?,?,?,?,?,?)");
      foreach($items as $it){
        $stmtDet->execute([$pid, $it['kode'], $it['nama'], (int)$it['qty'], (int)$it['harga_beli'], (int)$it['qty']*(int)$it['harga_beli']]);
        adjust_stock($pdo, $it['kode'], $location, (int)$it['qty']);
      }
      $pdo->commit();
      header('Location: /tokoapp/purchase_view.php?id='.$pid);
      exit;
    } catch(Exception $e){
      $pdo->rollBack();
      echo "<mark>Gagal simpan pembelian: ".$e->getMessage()."</mark>";
    }
  }
}

$suppliers = $pdo->query("SELECT id, nama FROM suppliers ORDER BY nama")->fetchAll();
?>
<article>
  <h3>Pembelian (Restock)</h3>
  <div class="grid">
    <label>Lokasi
      <select id="location">
        <option value="gudang">Gudang</option>
        <option value="toko">Toko</option>
      </select>
    </label>
    <label>Supplier
      <select id="supplier_id">
        <option value="">-</option>
        <?php foreach($suppliers as $s){ echo "<option value='{$s['id']}'>".htmlspecialchars($s['nama'])."</option>"; } ?>
      </select>
    </label>
  </div>

  <article>
    <header>Tambah barang (ketik barcode/kode lalu Enter)</header>
    <input id="barcode" placeholder="Barcode / Kode Barang" autofocus>
  </article>

  <table class="table-small" id="tbl">
    <thead><tr><th>Kode</th><th>Nama</th><th class="right">Qty</th><th class="right">Harga Beli</th><th class="right">Total</th><th></th></tr></thead>
    <tbody></tbody>
    <tfoot><tr><th colspan="4" class="right">Subtotal</th><th class="right" id="subtotal">0</th><th></th></tr></tfoot>
  </table>

  <form method="post" onsubmit="return doSave(event)">
    <input type="hidden" name="payload" id="payload">
    <button class="no-print">Simpan Pembelian</button>
  </form>
</article>

<script>
const rows=[];
const tbody=document.querySelector('#tbl tbody');
const subtotalEl=document.getElementById('subtotal');
const barcodeEl=document.getElementById('barcode');

function fmt(n){ return new Intl.NumberFormat('id-ID').format(n); }

barcodeEl.addEventListener('keypress', async (e)=>{
  if(e.key==='Enter'){
    e.preventDefault();
    const q=barcodeEl.value.trim(); if(!q) return;
    const res = await fetch('/tokoapp/api/get_item.php?q='+encodeURIComponent(q));
    const it = await res.json();
    if(!it || !it.kode){ alert('Barang tidak ditemukan'); barcodeEl.value=''; return; }
    const exist = rows.find(r=>r.kode===it.kode);
    if(exist){ exist.qty++; } else { rows.push({kode:it.kode, nama:it.nama, qty:1, harga_beli: parseInt(it.harga_beli||0)}); }
    barcodeEl.value='';
    render();
  }
});

function render(){
  tbody.innerHTML='';
  let sub=0;
  rows.forEach((r,idx)=>{
    const total=r.qty*r.harga_beli; sub+=total;
    const tr=document.createElement('tr');
    tr.innerHTML=`<td>${r.kode}</td><td>${r.nama}</td>
      <td class="right"><input type="number" min="1" value="${r.qty}" data-idx="${idx}" style="width:5rem"></td>
      <td class="right"><input type="number" min="0" value="${r.harga_beli}" data-idx="${idx}" data-type="hb" style="width:8rem"></td>
      <td class="right">${fmt(total)}</td>
      <td><button data-idx="${idx}" class="outline contrast">Hapus</button></td>`;
    tbody.appendChild(tr);
  });
  subtotalEl.textContent = fmt(sub);
  bind();
}

function bind(){
  tbody.querySelectorAll('input[type=number]').forEach(inp=>{
    inp.onchange=(e)=>{
      const idx=parseInt(e.target.dataset.idx);
      if(e.target.dataset.type==='hb'){ rows[idx].harga_beli=parseInt(e.target.value||'0'); }
      else { rows[idx].qty=parseInt(e.target.value||'1'); }
      render();
    }
  });
  tbody.querySelectorAll('button').forEach(btn=>{
    btn.onclick=(e)=>{ e.preventDefault(); rows.splice(parseInt(btn.dataset.idx),1); render(); };
  });
}

function doSave(e){
  e.preventDefault();
  if(rows.length===0){ alert('Belum ada item'); return false; }
  const payload = {
    location: document.getElementById('location').value,
    supplier_id: document.getElementById('supplier_id').value || null,
    items: rows
  };
  document.getElementById('payload').value = JSON.stringify(payload);
  e.target.submit();
  return true;
}
</script>
<?php include __DIR__.'/includes/footer.php'; ?>
