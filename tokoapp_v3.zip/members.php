<?php
require_once __DIR__.'/includes/header.php';
require_login();
if($_SESSION['user']['role']!=='admin'){ echo "<p>Akses khusus admin.</p>"; include __DIR__.'/includes/footer.php'; exit; }

if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['save'])){
    $kode = $_POST['kode']; $nama = $_POST['nama']; $alamat = $_POST['alamat']; $tlp = $_POST['tlp'];
    $stmt = $pdo->prepare("INSERT INTO members(kode,nama,alamat,tlp) VALUES(?,?,?,?)
      ON DUPLICATE KEY UPDATE nama=VALUES(nama), alamat=VALUES(alamat), tlp=VALUES(tlp)");
    $stmt->execute([$kode,$nama,$alamat,$tlp]);
  }
  if(isset($_POST['delete'])){
    $kode = $_POST['kode'];
    $pdo->prepare("DELETE FROM members WHERE kode=?")->execute([$kode]);
  }
}
$members = $pdo->query("SELECT * FROM members ORDER BY created_at DESC LIMIT 200")->fetchAll();
?>
<article>
  <h3>Master Member</h3>
  <details open><summary>Tambah/Update Member</summary>
    <form method="post" class="grid">
      <label>Kode <input name="kode" required></label>
      <label>Nama <input name="nama" required></label>
      <label>Alamat <input name="alamat"></label>
      <label>Telepon <input name="tlp"></label>
      <button name="save" value="1">Simpan</button>
    </form>
  </details>
  <h4>Daftar Member</h4>
  <table class="table-small">
    <thead><tr><th>Kode</th><th>Nama</th><th>Alamat</th><th>Telepon</th><th>Poin</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php foreach($members as $m): ?>
      <tr>
        <td><?=htmlspecialchars($m['kode'])?></td>
        <td><?=htmlspecialchars($m['nama'])?></td>
        <td><?=htmlspecialchars($m['alamat'])?></td>
        <td><?=htmlspecialchars($m['tlp'])?></td>
        <td><?=$m['poin']?></td>
        <td>
          <form method="post" class="no-print" onsubmit="return confirm('Hapus member?')">
            <input type="hidden" name="kode" value="<?=htmlspecialchars($m['kode'])?>">
            <button name="delete" value="1" class="contrast outline">Hapus</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</article>
<?php include __DIR__.'/includes/footer.php'; ?>
