<?php
require_once __DIR__.'/includes/header.php';
require_login();
if($_SESSION['user']['role']!=='admin'){ echo "<p>Akses khusus admin.</p>"; include __DIR__.'/includes/footer.php'; exit; }

if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['save'])){
    $kode = $_POST['kode']; $barcode = $_POST['barcode'] ?: null; $nama = $_POST['nama'];
    $hb = (int)($_POST['harga_beli'] ?? 0);
    $h1 = (int)($_POST['harga_jual1'] ?? 0);
    $h2 = (int)($_POST['harga_jual2'] ?? 0);
    $h3 = (int)($_POST['harga_jual3'] ?? 0);
    $h4 = (int)($_POST['harga_jual4'] ?? 0);
    $stmt = $pdo->prepare("INSERT INTO items(kode,barcode,nama,harga_beli,harga_jual1,harga_jual2,harga_jual3,harga_jual4, min_stock)
      VALUES(?,?,?,?,?,?,?,?,?)
      ON DUPLICATE KEY UPDATE barcode=VALUES(barcode), nama=VALUES(nama), harga_beli=VALUES(harga_beli),
      harga_jual1=VALUES(harga_jual1), harga_jual2=VALUES(harga_jual2), harga_jual3=VALUES(harga_jual3), harga_jual4=VALUES(harga_jual4, min_stock)");
    $stmt->execute([$kode,$barcode,$nama,$hb,$h1,$h2,$h3,$h4,(int)($_POST['min_stock']??0)]);
    ensure_stock_rows($pdo, $kode);
    ensure_stock_rows($pdo, $kode);
  }
  if(isset($_POST['delete'])){
    $kode = $_POST['kode'];
    $pdo->prepare("DELETE FROM items WHERE kode=?")->execute([$kode]);
  }
}

$items = $pdo->query("SELECT i.*, (SELECT qty FROM item_stocks WHERE item_kode=i.kode AND location='gudang') AS stok_gudang, (SELECT qty FROM item_stocks WHERE item_kode=i.kode AND location='toko') AS stok_toko FROM items i ORDER BY i.created_at DESC LIMIT 200")->fetchAll();
?>
<article>
  <h3>Master Barang</h3>
  <details open>
    <summary>Tambah/Update Barang</summary>
    <form method="post" class="grid">
      <label>Kode <input name="kode" required></label>
      <label>Barcode <input name="barcode"></label>
      <label>Nama <input name="nama" required></label>
      <label>Harga Beli <input name="harga_beli" type="number" min="0" value="0"></label>
      <label>Harga Jual 1 <input name="harga_jual1" type="number" min="0" value="0"></label>
      <label>Harga Jual 2 <input name="harga_jual2" type="number" min="0" value="0"></label>
      <label>Harga Jual 3 <input name="harga_jual3" type="number" min="0" value="0"></label>
      <label>Harga Jual 4 <input name="harga_jual4" type="number" min="0" value="0"></label>
      <label>Min Stok <input name="min_stock" type="number" min="0" value="0"></label>
      <button name="save" value="1">Simpan</button>
    </form>
  </details>
  <h4>Daftar Barang</h4>
  <table class="table-small">
    <thead><tr><th>Kode</th><th>Barcode</th><th>Nama</th><th class="right">Min</th><th class="right">Gudang</th><th class="right">Toko</th><th class="right">HB</th><th class="right">H1</th><th class="right">H2</th><th class="right">H3</th><th class="right">H4</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php foreach($items as $it): ?>
        <tr>
          <td><?=htmlspecialchars($it['kode'])?></td>
          <td><?=htmlspecialchars($it['barcode'])?></td>
          <td><?=htmlspecialchars($it['nama'])?></td>
          <td class="right"><?=(int)($it['min_stock']??0)?></td><td class="right"><?=(int)($it['stok_gudang']??0)?></td><td class="right"><?=(int)($it['stok_toko']??0)?></td><td class="right"><?=rupiah($it['harga_beli'])?></td>
          <td class="right"><?=rupiah($it['harga_jual1'])?></td>
          <td class="right"><?=rupiah($it['harga_jual2'])?></td>
          <td class="right"><?=rupiah($it['harga_jual3'])?></td>
          <td class="right"><?=rupiah($it['harga_jual4'])?></td>
          <td>
            <form method="post" class="no-print" onsubmit="return confirm('Hapus barang ini?')">
              <input type="hidden" name="kode" value="<?=htmlspecialchars($it['kode'])?>">
              <button name="delete" value="1" class="contrast outline">Hapus</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</article>
<?php include __DIR__.'/includes/footer.php'; ?>
