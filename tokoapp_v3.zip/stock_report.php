<?php
require_once __DIR__.'/includes/header.php';
require_login();
require_role(['admin']); // stok report untuk admin
$loc = $_GET['loc'] ?? '';
$where = '';
$params = [];
if($loc==='gudang' || $loc==='toko'){ $where='WHERE s.location=?'; $params[]=$loc; }
$stmt = $pdo->prepare("SELECT i.kode, i.nama, s.location, s.qty
  FROM item_stocks s JOIN items i ON i.kode=s.item_kode
  $where
  ORDER BY i.nama, s.location");
$stmt->execute($params);
$data = $stmt->fetchAll();
?>
<article>
  <h3>Laporan Stok per Lokasi</h3>
  <form class="no-print">
    <label>Lokasi
      <select name="loc" onchange="this.form.submit()">
        <option value="">Semua</option>
        <option value="gudang" <?=$loc==='gudang'?'selected':''?>>Gudang</option>
        <option value="toko" <?=$loc==='toko'?'selected':''?>>Toko</option>
      </select>
    </label>
    <button type="button" onclick="window.print()">Cetak</button>
  </form>
  <table class="table-small">
    <thead><tr><th>Kode</th><th>Nama</th><th>Lokasi</th><th class="right">Qty</th></tr></thead>
    <tbody>
      <?php foreach($data as $r): ?>
      <tr>
        <td><?=htmlspecialchars($r['kode'])?></td>
        <td><?=htmlspecialchars($r['nama'])?></td>
        <td><?=$r['location']?></td>
        <td class="right"><?=(int)$r['qty']?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</article>
<?php include __DIR__.'/includes/footer.php'; ?>
